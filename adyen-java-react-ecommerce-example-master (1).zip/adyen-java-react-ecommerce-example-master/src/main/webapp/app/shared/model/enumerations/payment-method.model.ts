export const enum PaymentMethod {
  CREDIT_CARD = 'CREDIT_CARD',
  IDEAL = 'IDEAL'
}
