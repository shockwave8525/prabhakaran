/**
 * Data Transfer Objects.
 */
package com.adyen.demo.store.service.dto;
