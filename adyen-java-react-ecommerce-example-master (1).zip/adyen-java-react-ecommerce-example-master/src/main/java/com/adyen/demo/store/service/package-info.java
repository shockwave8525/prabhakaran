/**
 * Service layer beans.
 */
package com.adyen.demo.store.service;
