/**
 * View Models used by Spring MVC REST controllers.
 */
package com.adyen.demo.store.web.rest.vm;
