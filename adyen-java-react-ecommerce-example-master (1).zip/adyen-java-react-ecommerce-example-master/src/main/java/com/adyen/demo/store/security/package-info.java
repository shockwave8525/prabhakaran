/**
 * Spring Security configuration.
 */
package com.adyen.demo.store.security;
