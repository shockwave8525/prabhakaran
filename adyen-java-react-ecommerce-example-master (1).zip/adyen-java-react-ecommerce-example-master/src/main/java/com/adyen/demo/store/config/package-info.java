/**
 * Spring Framework configuration files.
 */
package com.adyen.demo.store.config;
