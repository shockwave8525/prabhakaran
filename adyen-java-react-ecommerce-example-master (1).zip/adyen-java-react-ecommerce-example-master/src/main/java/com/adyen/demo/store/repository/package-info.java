/**
 * Spring Data JPA repositories.
 */
package com.adyen.demo.store.repository;
