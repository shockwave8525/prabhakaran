/**
 * JPA domain objects.
 */
package com.adyen.demo.store.domain;
